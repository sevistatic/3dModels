Included in this zip file are:
Revan.obj
Revan.max (version 2010+)
revan_diffuse.tga
revan_spec.tga
uvw.jpg

I am releasing this model and textures to the JKA community, a place where i grew (in)famous for good, bad, and ugly models, and where i learned my trade.
this model is quite old, and i never got a chance to fully realise what i wanted to do with it. so i'm giving it back to the community i once belonged to.

I would like to request that no alterations be made to the textures, however, you may re-texture the model from scratch using the provided UVW map. 
i would also like to request that no modifications be made to the model itself, EXCEPT that you may re-pose the model in order to rig it to the JKA skeleton.

if you have any other questions regarding permissions, please E-Mail me at: Lee_Devonald@crazyferretstudios.com

This will be part of my ongoing portfolio, so when uploading to jk3files, or whichever host, please be careful to credit:
Lee (Almighty_gir) Devonald, for the mesh, and textures.

thank you very much, enjoy!